/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package condominio;

/**
 *
 * @author migas
 */
public class Pagamentos extends Condomino {
    Fracao andar;
    Fracao area;
    private String estado;

    public Pagamentos(int nif, String morada, String proprietario) {
        super(nif, morada, proprietario);
    }
    
    
    
    
}
