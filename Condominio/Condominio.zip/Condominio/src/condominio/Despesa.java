/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package condominio;

/**
 *
 * @author migas
 */
public class Despesa {
    
    private String tipodespesa;
    private double valordespesa;
    
    
    //construtor//
    
    public Despesa (String tipodespesa,double valordespesa) {
        this.tipodespesa = tipodespesa;
        this.valordespesa = valordespesa;
        
    }

    /**
     * @return the tipodespesa
     */
    public String getTipodespesa() {
        return tipodespesa;
    }

    /**
     * @param tipodespesa the tipodespesa to set
     */
    public void setTipodespesa(String tipodespesa) {
        this.tipodespesa = tipodespesa;
    }

    /**
     * @return the valordespesa
     */
    public double getValordespesa() {
        return valordespesa;
    }

    /**
     * @param valordespesa the valordespesa to set
     */
    public void setValordespesa(double valordespesa) {
        this.valordespesa = valordespesa;
    }
    
    
}
