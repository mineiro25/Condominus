/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package condominio;

import java.util.ArrayList;

/**
 *
 * @author migas
 */
public class Orcamento {
  double totaldespesa = 0;
  private double honorarios;
  private ArrayList <Despesa> listadespesas = new ArrayList<>();  
  private String estado;
  
  
  public void Orcamento (double honorarios,Despesa a, String estado) {
      this.honorarios = honorarios;
        listadespesas.add(a);
       this.estado=estado;  
        }

   
    public double getHonorarios() {
        return honorarios;
    }

    /**
     * @param honorarios the honorarios to set
     */
    public void setHonorarios(double honorarios) {
        this.honorarios = honorarios;
    }

    /**
     * @return the listadespesas
     */
    public ArrayList <Despesa> getListadespesas() {
        return listadespesas;
    }

    /**
     * @param listadespesas the listadespesas to set
     */
    public void setListadespesas(ArrayList <Despesa> listadespesas) {
        this.listadespesas = listadespesas;
    }
    
    //metodos//
    
    public double somadespesas() {
        
        double despesa;
        for (int i=0;i < listadespesas.size(); i++) {
          despesa=  listadespesas.get(i).getValordespesa();
        totaldespesa = despesa + totaldespesa;
                    
        }
        return totaldespesa;
    }
    
    public double totalorçamento() {
        double orçamento = 0;
        orçamento = totaldespesa + honorarios;
        return orçamento;
    }
    
}
