/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package condominio;

import java.util.ArrayList;

/**
 *
 * @author jjoao
 */
public class Condominio {
   private int area;
   private String localizacao;
   private String codigoPostal;
   ArrayList <Fracao> listafracoes = new ArrayList<>();
   
   
   public Condominio (int areaC, String localizacaoC, String codigoPostalC) {
       this.area=areaC;
       this.localizacao=localizacaoC;
       this.codigoPostal=codigoPostalC;
   }
    
   public void Condominio (Fracao a) {
   listafracoes.add(a);
   }
   
    /**
     * @return the area
     */
    public int getArea() {
        return area;
    }

    /**
     * @param area the area to set
     */
    public void setArea(int area) {
        this.area = area;
    }

    /**
     * @return the localizacao
     */
    public String getLocalizacao() {
        return localizacao;
    }

    /**
     * @param localizacao the localizacao to set
     */
    public void setLocalizacao(String localizacao) {
        this.localizacao = localizacao;
    }

    /**
     * @return the codigoPostal
     */
    public String getCodigoPostal() {
        return codigoPostal;
    }

    /**
     * @param codigoPostal the codigoPostal to set
     */
    public void setCodigoPostal(String codigoPostal) {
        this.codigoPostal = codigoPostal;
    }
   
   
 
}
